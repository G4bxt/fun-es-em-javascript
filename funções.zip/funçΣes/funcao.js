// Problema 1 - Função lembrete
function lembrete() {
    console.log('Regue as plantas');
    alert('Regue as plantas'); // Exibe também em um alerta
}

// Problema 2 - Função saudação em espanhol
function saudacaoEspanhol() {
    console.log('Buenas tardes');
    alert('Buenas tardes'); // Exibe também em um alerta
}
